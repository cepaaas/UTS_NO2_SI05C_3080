/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no2_c_3080;

/**
 *
 * @author lenovo
 */
public class ProjectPlanner_3080 extends Employess_3080{
    public float Komisi_3080;
    public float TotalHslProyek_3080;
    public double Totalgaji_3080;
    
    public ProjectPlanner_3080(){
        
    }
            
    public double TotalGaji_3080(){
        Totalgaji_3080 = GajiPokok_3080 + (Komisi_3080 * TotalHslProyek_3080) - (GajiPokok_3080 *5/100);
        return Totalgaji_3080;
    }
    
    public void TampilData_3080(){
        System.out.println("Project Plannner");
        Tampil_3080();
        System.out.println("Total Gaji: " + Totalgaji_3080);
    }
}
