/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.uts_no2_c_3080;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author lenovo
 */
public class UTS_NO2_C_3080 {

    public static void main(String[] args) {
        SalariedEmployee_3080 se_3080 = new SalariedEmployee_3080();
        CommissionEmployee_3080 ce_3080 = new CommissionEmployee_3080();
        ProjectPlanner_3080 pp_3080 = new ProjectPlanner_3080();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));        
        try{
            System.out.println("Data Pegawai");
            System.out.print("Nama: ");
            se_3080.Nama_3080 = br.readLine();
            System.out.print("NIP: ");
            se_3080.NIP_3080 = br.readLine();
            System.out.print("Gaji Pokok: ");
            se_3080.GajiPokok_3080 = Float.parseFloat(br.readLine());
            se_3080.TampilData_3080();
            
            System.out.print("Nama: ");
            ce_3080.Nama_3080 = br.readLine();
            System.out.print("NIP: ");
            ce_3080.NIP_3080 = br.readLine();
            System.out.print("GajiPokok: ");
            ce_3080.GajiPokok_3080 = Float.parseFloat(br.readLine());
            System.out.print("Komisi: ");
            ce_3080.Komisi_3080 = Float.parseFloat(br.readLine());
            System.out.print("Total Penjualan: ");
            ce_3080.TotalPenjualan_3080 = Float.parseFloat(br.readLine());
            ce_3080.TotalGaji_3080();
            ce_3080.TampilData_3080();
            
            System.out.print("Nama: ");
            pp_3080.Nama_3080 = br.readLine();
            System.out.print("NIP: ");
            pp_3080.NIP_3080 = br.readLine();
            System.out.print("Gaji Pokok: ");
            pp_3080.GajiPokok_3080 = Float.parseFloat(br.readLine());
            System.out.print("Komisi: ");
            pp_3080.Komisi_3080 = Float.parseFloat(br.readLine());
            System.out.print("Total Hasil Proyek: ");
            pp_3080.TotalHslProyek_3080 = Float.parseFloat(br.readLine());
            pp_3080.TotalGaji_3080();
            pp_3080.TampilData_3080();
        }catch(Exception ex){
            System.out.println(ex);
        }
    }
}
